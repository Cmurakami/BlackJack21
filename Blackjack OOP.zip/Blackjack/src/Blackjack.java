import java.util.Scanner;

public class Blackjack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//play_deck is the dealer's deck
		Deck play_deck = new Deck();
		play_deck.createCompDk();
		play_deck.shuff();
	
	
	//player_hand represents the player's cards
	Deck player_hand = new Deck();
	//player_cash holds player money
	double player_cash = 25.0;
	//dealer_hand represents the dealer's cards
	Deck dealer_hand = new Deck();
	
	Scanner player_inp = new Scanner(System.in);
	
	//start game
while (player_cash > 0) {
	System.out.println("Your current amount: $" + player_cash + "; place your bet");
	double user_bet = player_inp.nextDouble();
	boolean finish_round = false;
	if(user_bet > player_cash) {
		System.out.println("You are betting too much money");
		break;
		}
	
	//Player receives cards
	player_hand.take(play_deck);
	player_hand.take(play_deck);
	
	//Dealer receives cards
	dealer_hand.take(play_deck);
	dealer_hand.take(play_deck);
	
	while (true) {
		//displays player's hand
		System.out.println(" ");
		System.out.println("Your hand is: " + player_hand.toString());
		
		//displays amount
		System.out.println("Your hand's total amount is: " + player_hand.crdsVal());
		
		//displays dealer's cards
		System.out.println(" ");
		System.out.println("Dealer's hand: " + dealer_hand.receiveCard(0).toString());
		System.out.println(" ");
		
		System.out.println("Type 1 to Hit, or 2 to Stay");
		int reply = player_inp.nextInt();
		
		//if player hits
		if(reply == 1) {
			player_hand.take(play_deck);
			System.out.println("You drew: " + player_hand.receiveCard(player_hand.amount_in_deck()-1).toString());
			//if player bust
			if (player_hand.crdsVal() > 21) {
				System.out.println(" ");
				System.out.println("Bust, your total: " + player_hand.crdsVal());
				System.out.println(" ");
				player_cash -= user_bet;
				finish_round = true;
				break;
			}
		}
		//if player stand
		if (reply == 2) {
			break;
		}	
	}
	
	System.out.println("Dealer's hand: " + dealer_hand.toString());
	System.out.println(" ");
	if (dealer_hand.crdsVal() > player_hand.crdsVal()&&finish_round == false){
		System.out.println ("Dealer wins " + dealer_hand.crdsVal() + " to " + player_hand.crdsVal());
		player_cash -= user_bet;
		finish_round = true;
	}
	while ((dealer_hand.crdsVal() < 17) && finish_round == false) {
		dealer_hand.take(play_deck);
			System.out.println("Dealer draws: " + dealer_hand.receiveCard(dealer_hand.amount_in_deck()-1).toString());
		}
	System.out.println("Dealer's total hand value: " + dealer_hand.crdsVal());
	
	//if dealer busts
	if ((dealer_hand.crdsVal() > 21) && finish_round == false) {
		System.out.println(" ");
		System.out.println("Dealer busted. You win");
		player_cash += user_bet;
		finish_round = true;
	}
	
	//if push
	if ((dealer_hand.crdsVal() == player_hand.crdsVal()) && finish_round == false) {
		System.out.println(" ");
		System.out.println("The result is a push (tie)");
		finish_round = true;
	}
	
	//determine player win
	if ((player_hand.crdsVal() > dealer_hand.crdsVal()) && finish_round == false) {
		System.out.println(" ");
		System.out.println("You win the round");
		player_cash += user_bet;
		finish_round = true;
	} else if (finish_round == false){
		System.out.println(" ");
		System.out.println("The dealer has won");
		player_cash -= user_bet;
	}
	
	player_hand.move_all(play_deck);
	dealer_hand.move_all(play_deck);
	System.out.println("Round is finished");
	System.out.println(" ");
		}
System.out.println("Game has ended");
player_inp.close();
	}
	}




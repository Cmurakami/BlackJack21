
public class Card {
	private Suit aSuit;
	private Val aVal;
	
	public Card(Suit suit, Val val) {
		this.aSuit = suit;
		this.aVal = val;
	}
	public String toString() {
		return this.aVal.toString() + " of " + 	this.aSuit.toString();
	}
	
	public Val getVal() {
		return this.aVal;
	}
}

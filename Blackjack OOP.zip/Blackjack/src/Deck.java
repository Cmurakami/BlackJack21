import java.util.ArrayList;
import java.util.Random;
public class Deck {

	private ArrayList<Card> crds;
	
	public Deck() {
		//creates new deck of cards
		this.crds = new ArrayList<Card>();
	}
	
	//adds cards to deck
	public void createCompDk () {
		for(Suit card_suit : Suit.values()) {
			for(Val card_value : Val.values()) {
				this.crds.add(new Card(card_suit,card_value));
			}
		}
	}
	
	//shuffle deck
	public void shuff() {
		//new arraylist holds shuffled cards temporarily
		ArrayList<Card> temp_deck = new ArrayList<Card>();
		//pick random from original deck and copy to new
		Random rdm = new Random();
		int rdm_card_ind = 0;
		int orig_size = this.crds.size();
		for(int i = 0; i < orig_size; i++) {
			rdm_card_ind = rdm.nextInt((this.crds.size()-1-0) +1) + 0;
			temp_deck.add(this.crds.get(rdm_card_ind));
			this.crds.remove(rdm_card_ind);
		}
		this.crds = temp_deck;
	}
	
	//take card from deck
	public void takeOutCard (int i) {
		this.crds.remove(i);
	}
	
	//receive card from deck
	public Card receiveCard (int i) {
		return this.crds.get(i);
	}
	
	//put card in deck
	public void putCard(Card putCard) {
		this.crds.add(putCard);
	}
	
	//take card from top of deck
	public void take(Deck from) {
		this.crds.add(from.receiveCard(0));
		from.takeOutCard(0);
	}
	
	public String toString() {
		String card_result = "";
		int i = 0;
		for (Card some_card : this.crds) {
			card_result += "\n" + some_card.toString();
			i++;
		}
		return card_result;
	}
	
	public void move_all(Deck move_to) {
		int this_size = this.crds.size();
		for (int i = 0; i < this_size; i++) {
			move_to.putCard(this.receiveCard(i));
		}
		for (int i = 0; i < this_size; i++) {
			this.takeOutCard(0);
		}
	}
	
	public int amount_in_deck() {
		return this.crds.size();
	}
	
	//value of deck
	public int crdsVal() {
		int total_val = 0;
		int acee = 0;
		for(Card some_card : this.crds) {
			switch(some_card.getVal()) {
			case Two: total_val += 2; break;
			case Three: total_val += 3; break;
			case Four: total_val += 4; break;
			case Five: total_val += 5; break;
			case Six: total_val += 6; break;
			case Seven: total_val += 7; break;
			case Eight: total_val += 8; break;
			case Nine: total_val += 9; break;
			case Ten: total_val += 10; break;
			case Jack: total_val += 10; break;
			case Queen: total_val += 10; break;
			case King: total_val += 10; break;
			case Ace: acee += 1; break;
			}
		}
		
		//determines total value including aces
		for (int i = 0; i < acee; i++) {
			if (total_val > 10) {
				total_val += 1;
			} else {
				total_val += 11;
			}			
		}
		return total_val;
	}
}

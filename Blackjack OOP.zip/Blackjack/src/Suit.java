
public enum Suit {
	Hearts, Clubs, Diamonds, Spades
}
